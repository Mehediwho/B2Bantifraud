"""Synthetic transactions for the demo. NOT real PayPal or merchant data."""
import random, time

COUNTRIES = ["US", "GB", "DE", "CA", "BD", "ID"]
GOOD = ["gmail.com", "outlook.com", "yahoo.com", "proton.me"]
BAD = ["mailinator.com", "tempmail.com", "10minutemail.com"]

def generate(n=300, seed=7):
    r = random.Random(seed)
    now, out = int(time.time()), []
    for i in range(n):
        c = r.choice(COUNTRIES)
        out.append(dict(id=f"TX{1000+i}", ts=now - r.randint(0, 7 * 86400),
            amount=round(r.lognormvariate(3.6, 0.6), 2), card_id=f"C{r.randint(1, 120)}",
            card_country=c, ip_country=c if r.random() > 0.04 else r.choice(COUNTRIES),
            cvv_match=r.random() > 0.01, avs_match=r.random() > 0.05,
            email_domain=r.choice(GOOD), account_age_days=r.randint(5, 900)))
    for k in range(8):  # injected fraud bursts: same card, minutes apart
        base, card = now - r.randint(0, 6 * 86400), f"CF{k}"
        cc, ic = r.sample(COUNTRIES, 2)
        for j in range(r.randint(3, 4)):
            out.append(dict(id=f"TX{5000+k*10+j}", ts=base + j * r.randint(40, 200),
                amount=round(r.uniform(300, 900), 2), card_id=card, card_country=cc,
                ip_country=ic, cvv_match=r.random() > 0.5, avs_match=False,
                email_domain=r.choice(BAD), account_age_days=r.randint(0, 3)))
    return out

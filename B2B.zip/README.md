# AI Fraud & Risk Radar for Small Merchants (demo)

Flask + vanilla JS + Tailwind (CDN). Uses **synthetic data** and a **rule-based + z-score** scorer
(no trained ML model). Not connected to PayPal.

## Run
    pip install -r requirements.txt
    python app.py   # http://127.0.0.1:5000

## Layout
- `risk_engine.py` – scoring rules (each point is explained)
- `data_gen.py` – synthetic transactions with injected fraud bursts
- `app.py` – API: `/api/summary`, `/api/transactions?level=`, `POST /api/score`
- `templates/`, `static/` – dashboard UI

## Next steps
Replace `data_gen.py` with a real transaction feed (check PayPal's current developer docs for
the actual API), add auth, persist data, and validate rules against labeled data.

const $ = (s) => document.querySelector(s);
const esc = (v) => String(v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = (n) => "$" + Number(n).toLocaleString(undefined, { maximumFractionDigits: 0 });
const reasonsHtml = (r) => r.length
  ? "<ul class='list-disc ml-5 space-y-1 mt-2'>" + r.map((x) => `<li>+${x.points}: ${esc(x.reason)}</li>`).join("") + "</ul>"
  : "<p class='text-slate-400'>No risk signals triggered.</p>";

async function loadSummary() {
  const s = await (await fetch("/api/summary")).json();
  const k = [["Transactions", s.total], ["Volume", money(s.volume)], ["Volume at risk", money(s.at_risk)], ["High-risk", s.high]];
  $("#kpis").innerHTML = k.map(([a, b]) => `<div class="card p-4"><div class="text-slate-400 text-xs">${a}</div><div class="text-2xl font-bold">${b}</div></div>`).join("");
  const colors = { high: "bg-red-500", medium: "bg-amber-500", low: "bg-green-500" };
  $("#dist").innerHTML = ["high", "medium", "low"].map((l) =>
    `<div><div class="flex justify-between text-xs mb-1"><span class="capitalize">${l}</span><span>${s[l]}</span></div>
     <div class="h-2 bg-slate-800 rounded"><div class="bar h-2 rounded ${colors[l]}" style="width:${(s[l] / s.total) * 100}%"></div></div></div>`).join("");
}

let rows = [];
async function loadRows() {
  rows = await (await fetch("/api/transactions?level=" + $("#filter").value)).json();
  $("#rows").innerHTML = rows.map((t, i) =>
    `<tr data-i="${i}" class="border-t border-slate-800"><td class="py-2">${esc(t.id)}</td><td>$${t.amount.toFixed(2)}</td>
     <td>${esc(t.card_country)}</td><td>${esc(t.ip_country)}</td><td>${t.risk.score}</td>
     <td><span class="pill ${t.risk.level}">${t.risk.level}</span></td></tr>`).join("");
}

$("#rows").addEventListener("click", (e) => {
  const tr = e.target.closest("tr"); if (!tr) return;
  const t = rows[tr.dataset.i];
  $("#detail").innerHTML = `<div class="p-4 rounded bg-slate-900"><b>${esc(t.id)}</b> — score ${t.risk.score}${reasonsHtml(t.risk.reasons)}</div>`;
});
$("#filter").addEventListener("change", loadRows);

$("#f").addEventListener("submit", async (e) => {
  e.preventDefault();
  const d = Object.fromEntries(new FormData(e.target));
  d.cvv_match = e.target.cvv_match.checked; d.avs_match = e.target.avs_match.checked;
  d.account_age_days = d.account_age_days === "" ? 365 : d.account_age_days;
  const res = await fetch("/api/score", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(d) });
  const j = await res.json();
  $("#result").innerHTML = res.ok
    ? `<div class="p-4 rounded bg-slate-900">Score <b>${j.score}</b> <span class="pill ${j.level}">${j.level}</span>${reasonsHtml(j.reasons)}</div>`
    : `<p class="text-red-400">${esc(j.error)}</p>`;
});

loadSummary(); loadRows();

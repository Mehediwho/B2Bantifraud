from flask import Flask, jsonify, render_template, request
from collections import Counter
import data_gen, risk_engine as eng

app = Flask(__name__)
TXNS = eng.score_all(data_gen.generate())
MU, SD = eng.stats(TXNS)

@app.get("/")
def index():
    return render_template("index.html")

@app.get("/api/summary")
def summary():
    lv = Counter(t["risk"]["level"] for t in TXNS)
    flagged = [t for t in TXNS if t["risk"]["level"] != "low"]
    return jsonify(total=len(TXNS), high=lv["high"], medium=lv["medium"], low=lv["low"],
                   volume=round(sum(t["amount"] for t in TXNS), 2),
                   at_risk=round(sum(t["amount"] for t in flagged), 2),
                   avg_amount=round(MU, 2))

@app.get("/api/transactions")
def transactions():
    lvl = request.args.get("level")
    rows = [t for t in TXNS if not lvl or t["risk"]["level"] == lvl]
    rows.sort(key=lambda t: -t["risk"]["score"])
    return jsonify(rows[:200])

@app.post("/api/score")
def score():
    d = request.get_json(silent=True) or {}
    try:
        t = dict(amount=float(d["amount"]), card_country=str(d["card_country"]).upper()[:2],
                 ip_country=str(d["ip_country"]).upper()[:2], cvv_match=bool(d.get("cvv_match", True)),
                 avs_match=bool(d.get("avs_match", True)),
                 email_domain=str(d.get("email_domain", "")).lower()[:100],
                 account_age_days=int(d.get("account_age_days", 365)), ts=int(__import__("time").time()))
        if t["amount"] < 0 or t["account_age_days"] < 0:
            raise ValueError
    except (KeyError, ValueError, TypeError):
        return jsonify(error="Invalid input"), 400
    return jsonify(eng.score_one(t, MU, SD, []))

if __name__ == "__main__":
    app.run(debug=True)

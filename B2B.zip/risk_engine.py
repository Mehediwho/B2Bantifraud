"""Transparent risk scoring: weighted rules + a z-score anomaly signal.
No trained ML model is used; every point added is explained in `reasons`."""
from collections import defaultdict
from datetime import datetime, timezone
from statistics import mean, pstdev

DISPOSABLE = {"mailinator.com", "tempmail.com", "10minutemail.com", "guerrillamail.com"}

def level_for(score):
    return "high" if score >= 70 else "medium" if score >= 40 else "low"

def score_one(t, mu, sd, prior_ts):
    pts, reasons = 0, []
    def add(p, msg):
        nonlocal pts
        pts += p
        reasons.append({"points": p, "reason": msg})
    z = (t["amount"] - mu) / sd
    if z >= 3:
        add(25, f"Amount ${t['amount']:.2f} is {z:.1f} std devs above merchant mean (${mu:.2f})")
    elif z >= 2:
        add(12, f"Amount ${t['amount']:.2f} is {z:.1f} std devs above merchant mean (${mu:.2f})")
    vel = sum(1 for x in prior_ts if 0 <= t["ts"] - x <= 600)
    if vel >= 2:
        add(25, f"{vel + 1} attempts on the same card within 10 minutes")
    if t["ip_country"] != t["card_country"]:
        add(20, f"IP country {t['ip_country']} differs from card country {t['card_country']}")
    if t["cvv_match"] is False:
        add(20, "CVV check failed")
    if t["avs_match"] is False:
        add(10, "Address verification (AVS) mismatch")
    if t["email_domain"] in DISPOSABLE:
        add(15, f"Disposable email domain ({t['email_domain']})")
    if t["account_age_days"] < 7:
        add(10, f"Buyer account only {t['account_age_days']} day(s) old")
    if datetime.fromtimestamp(t["ts"], timezone.utc).hour < 5:
        add(5, "Placed between 00:00 and 05:00 UTC")
    score = min(100, pts)
    return {"score": score, "level": level_for(score), "reasons": reasons}

def stats(txns):
    amts = [t["amount"] for t in txns] or [0]
    return mean(amts), (pstdev(amts) or 1.0)

def score_all(txns):
    txns = sorted(txns, key=lambda t: t["ts"])
    mu, sd = stats(txns)
    seen = defaultdict(list)
    for t in txns:
        t["risk"] = score_one(t, mu, sd, seen[t["card_id"]])
        seen[t["card_id"]].append(t["ts"])
    return txns
